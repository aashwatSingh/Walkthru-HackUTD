import Link from "next/link";
import { DoorOpen } from "lucide-react";
import { cn } from "@/lib/utils";

export function Logo({ className }: { className?: string }) {
  return (
    <Link
      href="/"
      className={cn("group flex items-center gap-2.5 font-heading font-bold tracking-tight", className)}
    >
      <span className="flex size-9 -rotate-6 items-center justify-center rounded-xl bg-primary text-primary-foreground transition-transform duration-300 group-hover:rotate-6 group-hover:scale-110">
        <DoorOpen className="size-5" />
      </span>
      <span className="text-xl">Walkthrough</span>
    </Link>
  );
}
