import Link from "next/link";
import { Logo } from "@/components/logo";
import { buttonVariants } from "@/components/ui/button";

export function AppHeader({ children }: { children?: React.ReactNode }) {
  return (
    <header className="no-print sticky top-0 z-30 border-b bg-background/85 backdrop-blur">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between gap-3 px-4 sm:px-6">
        <Logo />
        <div className="flex items-center gap-2">
          {children ?? (
            <Link href="/" className={buttonVariants({ variant: "ghost", size: "sm" })}>
              Back to site
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}
