"use client";

import { cn } from "@/lib/utils";

export function ChoiceGroup<T extends string>({
  value,
  onChange,
  options,
  label,
}: {
  value: T;
  onChange: (v: T) => void;
  options: { value: T; label: string; hint?: string }[];
  label: string;
}) {
  return (
    <div role="radiogroup" aria-label={label} className="grid grid-cols-2 gap-2">
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          role="radio"
          aria-checked={value === o.value}
          onClick={() => onChange(o.value)}
          className={cn(
            "rounded-2xl border px-4 py-3 text-left text-sm transition-all duration-200 active:scale-[0.98] outline-none focus-visible:ring-3 focus-visible:ring-ring/50",
            value === o.value
              ? "border-primary bg-accent text-foreground [&_.hint]:text-white/70"
              : "hover:border-primary hover:bg-primary hover:text-primary-foreground active:border-white active:bg-white active:text-black [&:hover_.hint]:text-black/70 [&:active_.hint]:text-black/70",
          )}
        >
          <div className="font-heading text-base font-bold">{o.label}</div>
          {o.hint && <div className="hint text-xs text-muted-foreground">{o.hint}</div>}
        </button>
      ))}
    </div>
  );
}
