"use client";

import { useEffect, useRef } from "react";

export function Reveal({
  children,
  delay = 0,
  tilt = 0,
  className,
}: {
  children: React.ReactNode;
  delay?: number;
  tilt?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          el.classList.add("is-visible");
          observer.disconnect();
        }
      },
      { threshold: 0.15, rootMargin: "0px 0px -40px 0px" },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      data-reveal
      className={className}
      style={{ transitionDelay: `${delay}ms`, "--reveal-tilt": `${tilt}deg` } as React.CSSProperties}
    >
      {children}
    </div>
  );
}

export function PopWords({ text, highlight = [], startDelay = 0 }: { text: string; highlight?: string[]; startDelay?: number }) {
  return (
    <>
      {text.split(" ").map((word, i) => {
        const hot = highlight.includes(word);
        return (
          <span key={i} className="inline-block whitespace-nowrap">
            <span
              className={
                hot
                  ? "animate-pop relative mx-[0.08em] inline-block -rotate-2 rounded-xl bg-primary px-[0.15em] text-primary-foreground"
                  : "animate-pop inline-block"
              }
              style={{ animationDelay: `${startDelay + i * 90}ms` }}
            >
              {word}
            </span>
            {"\u00a0"}
          </span>
        );
      })}
    </>
  );
}
