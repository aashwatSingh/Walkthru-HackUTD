import { Loader2 } from "lucide-react";
import { AppHeader } from "@/components/app-header";

export function PageLoading({ label }: { label: string }) {
  return (
    <>
      <AppHeader />
      <div className="flex flex-1 items-center justify-center gap-2 py-24 text-muted-foreground">
        <Loader2 className="size-4 animate-spin" /> {label}
      </div>
    </>
  );
}
