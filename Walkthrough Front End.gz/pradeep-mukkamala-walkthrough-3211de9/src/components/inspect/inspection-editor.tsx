"use client";

import { useRef, useState } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { ArrowLeft, ArrowRight, Camera, Check, FileText, Loader2, Plus, X } from "lucide-react";
import { toast } from "sonner";
import { AppHeader } from "@/components/app-header";
import { Badge } from "@/components/ui/badge";
import { Button, buttonVariants } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import {
  compressImage,
  conditionMeta,
  formatDateTime,
  inspectionProgress,
  inspectionStore,
  StorageFullError,
  uid,
  useInspections,
  type Condition,
  type Item,
} from "@/lib/inspections";
import { cn } from "@/lib/utils";

function safeUpdate(fn: () => void) {
  try {
    fn();
  } catch (e) {
    toast.error(e instanceof StorageFullError ? e.message : "Couldn't save that change.");
  }
}

function ItemCard({ item, onChange }: { item: Item; onChange: (patch: Partial<Item>) => void }) {
  const [note, setNote] = useState(item.note);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const needsDetail = item.condition === "damaged" && item.photos.length === 0;

  const addPhotos = async (files: FileList | null) => {
    if (!files?.length) return;
    setUploading(true);
    try {
      const photos = await Promise.all(
        Array.from(files).map(async (f) => ({
          id: uid(),
          dataUrl: await compressImage(f),
          takenAt: new Date().toISOString(),
        })),
      );
      safeUpdate(() => onChange({ photos: [...item.photos, ...photos] }));
    } catch {
      toast.error("One of those files couldn't be read as an image.");
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  return (
    <Card size="sm" className={cn("rounded-2xl transition-colors", item.condition && "ring-primary/30")}>
      <CardContent className="space-y-3">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2">
            <span
              className={cn(
                "flex size-5 items-center justify-center rounded-full border",
                item.condition ? "border-primary bg-primary text-primary-foreground" : "border-border",
              )}
            >
              {item.condition && <Check className="size-3" />}
            </span>
            <span className="text-base font-semibold">{item.name}</span>
          </div>
          <div role="radiogroup" aria-label={`${item.name} condition`} className="flex gap-1.5">
            {(Object.keys(conditionMeta) as Condition[]).map((c) => (
              <button
                key={c}
                type="button"
                role="radio"
                aria-checked={item.condition === c}
                onClick={() => safeUpdate(() => onChange({ condition: item.condition === c ? null : c }))}
                className={cn(
                  "flex items-center gap-1.5 rounded-full border px-3.5 py-1.5 text-xs font-bold transition-all duration-200 outline-none active:scale-95 focus-visible:ring-3 focus-visible:ring-ring/50",
                  item.condition === c ? conditionMeta[c].className : "text-muted-foreground hover:border-primary hover:bg-primary hover:text-primary-foreground active:border-white active:bg-white active:text-black",
                )}
              >
                <span className={cn("size-1.5 rounded-full", conditionMeta[c].dot)} />
                {conditionMeta[c].label}
              </button>
            ))}
          </div>
        </div>

        <Textarea
          placeholder={
            item.condition === "damaged"
              ? "Describe the damage: where it is, how big, and whether it was already there."
              : "Notes (optional): scuffs, stains, missing parts…"
          }
          value={note}
          onChange={(e) => setNote(e.target.value)}
          onBlur={() => note !== item.note && safeUpdate(() => onChange({ note }))}
          className="min-h-16 text-sm"
        />

        <div className="flex flex-wrap items-center gap-2">
          {item.photos.map((p) => (
            <div key={p.id} className="group relative">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={p.dataUrl}
                alt={`${item.name} photo taken ${formatDateTime(p.takenAt)}`}
                className="size-16 rounded-2xl border object-cover"
              />
              <button
                type="button"
                aria-label="Remove photo"
                onClick={() => safeUpdate(() => onChange({ photos: item.photos.filter((x) => x.id !== p.id) }))}
                className="absolute -top-1.5 -right-1.5 flex size-5 items-center justify-center rounded-full bg-foreground text-background opacity-90 sm:opacity-0 sm:group-hover:opacity-100"
              >
                <X className="size-3" />
              </button>
            </div>
          ))}
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            capture="environment"
            multiple
            className="hidden"
            onChange={(e) => addPhotos(e.target.files)}
          />
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="h-16 w-16 flex-col gap-1 rounded-2xl text-xs"
            disabled={uploading}
            onClick={() => fileRef.current?.click()}
          >
            {uploading ? <Loader2 className="animate-spin" /> : <Camera />}
            {uploading ? "Saving" : "Photo"}
          </Button>
          {needsDetail && (
            <span className="text-xs font-medium text-rose-300">Add a photo so the damage is on record.</span>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

export function InspectionEditor() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const inspections = useInspections();
  const inspection = inspections?.find((i) => i.id === id);
  const [roomIndex, setRoomIndex] = useState(0);
  const [newItem, setNewItem] = useState("");

  if (inspections === null) {
    return (
      <>
        <AppHeader />
        <div className="flex flex-1 items-center justify-center gap-2 text-muted-foreground">
          <Loader2 className="size-4 animate-spin" /> Loading inspection…
        </div>
      </>
    );
  }

  if (!inspection) {
    return (
      <>
        <AppHeader />
        <div className="flex flex-1 flex-col items-center justify-center gap-3 px-4 text-center">
          <h1 className="font-heading text-3xl font-bold">Inspection not found</h1>
          <p className="text-muted-foreground">It may have been deleted or saved in a different browser.</p>
          <Link href="/inspect" className={buttonVariants()}>
            Go to your walkthroughs
          </Link>
        </div>
      </>
    );
  }

  const room = inspection.rooms[Math.min(roomIndex, inspection.rooms.length - 1)];
  const progress = inspectionProgress(inspection);
  const isLast = roomIndex >= inspection.rooms.length - 1;

  const updateItem = (itemId: string, patch: Partial<Item>) =>
    inspectionStore.update(inspection.id, (i) => ({
      ...i,
      completedAt: null,
      rooms: i.rooms.map((r) =>
        r.id === room.id ? { ...r, items: r.items.map((it) => (it.id === itemId ? { ...it, ...patch } : it)) } : r,
      ),
    }));

  const addItem = (e: React.FormEvent) => {
    e.preventDefault();
    const name = newItem.trim();
    if (!name) return;
    safeUpdate(() =>
      inspectionStore.update(inspection.id, (i) => ({
        ...i,
        rooms: i.rooms.map((r) =>
          r.id === room.id
            ? { ...r, items: [...r.items, { id: uid(), name, condition: null, note: "", photos: [] }] }
            : r,
        ),
      })),
    );
    setNewItem("");
  };

  const finish = () => {
    if (progress.done < progress.total) {
      toast.warning(`${progress.total - progress.done} items still need a condition.`, {
        description: "Unrated items show as “Not inspected” on your report.",
      });
    }
    safeUpdate(() => inspectionStore.update(inspection.id, (i) => ({ ...i, completedAt: new Date().toISOString() })));
    router.push(`/inspect/${inspection.id}/report`);
  };

  return (
    <>
      <AppHeader>
        <Link href={`/inspect/${inspection.id}/report`} className={buttonVariants({ variant: "outline", size: "sm" })}>
          <FileText /> Report
        </Link>
      </AppHeader>
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-6 sm:px-6 sm:py-8">
        <Link href="/inspect" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="size-3.5" /> All walkthroughs
        </Link>
        <div className="mt-3 flex flex-col justify-between gap-4 md:flex-row md:items-end">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-heading text-3xl font-extrabold tracking-tight sm:text-4xl">
                {inspection.property} · {inspection.unit}
              </h1>
              <Badge variant="secondary">{inspection.type === "move-in" ? "Move-in" : "Move-out"}</Badge>
            </div>
            <p className="text-sm text-muted-foreground">Started {formatDateTime(inspection.createdAt)}</p>
          </div>
          <div className="w-full space-y-1.5 md:w-72">
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>
                {progress.done} of {progress.total} items rated
              </span>
              <span>{progress.percent}%</span>
            </div>
            <Progress value={progress.percent} />
          </div>
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-[220px_1fr]">
          <nav aria-label="Rooms" className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-1 lg:mx-0 lg:flex-col lg:px-0">
            {inspection.rooms.map((r, idx) => {
              const done = r.items.filter((it) => it.condition).length;
              const active = r.id === room.id;
              return (
                <button
                  key={r.id}
                  type="button"
                  onClick={() => setRoomIndex(idx)}
                  className={cn(
                    "flex shrink-0 items-center justify-between gap-3 rounded-2xl border px-4 py-3 text-left text-sm font-semibold transition-all duration-200 active:scale-[0.98]",
                    active ? "border-primary bg-accent" : "hover:border-primary hover:bg-primary hover:text-primary-foreground active:border-white active:bg-white active:text-black [&:hover_span]:text-black",
                  )}
                >
                  <span>{r.name}</span>
                  <span
                    className={cn(
                      "text-xs",
                      done === r.items.length ? "text-primary" : "text-muted-foreground",
                    )}
                  >
                    {done === r.items.length ? <Check className="size-3.5" /> : `${done}/${r.items.length}`}
                  </span>
                </button>
              );
            })}
          </nav>

          <section className="space-y-3">
            <h2 className="font-heading text-2xl font-bold">{room.name}</h2>
            {room.items.map((it) => (
              <ItemCard key={it.id} item={it} onChange={(patch) => updateItem(it.id, patch)} />
            ))}
            <form onSubmit={addItem} className="flex gap-2">
              <Input
                placeholder={`Add something else in the ${room.name.toLowerCase()}`}
                value={newItem}
                onChange={(e) => setNewItem(e.target.value)}
              />
              <Button type="submit" variant="outline" disabled={!newItem.trim()}>
                <Plus /> Add
              </Button>
            </form>

            <div className="flex items-center justify-between gap-2 border-t pt-5">
              <Button variant="ghost" disabled={roomIndex === 0} onClick={() => setRoomIndex((i) => i - 1)}>
                <ArrowLeft /> Previous
              </Button>
              {isLast ? (
                <Button size="lg" onClick={finish}>
                  Finish & generate report <FileText />
                </Button>
              ) : (
                <Button
                  size="lg"
                  onClick={() => {
                    setRoomIndex((i) => i + 1);
                    window.scrollTo({ top: 0, behavior: "smooth" });
                  }}
                >
                  Next: {inspection.rooms[roomIndex + 1].name} <ArrowRight />
                </Button>
              )}
            </div>
          </section>
        </div>
      </main>
    </>
  );
}
