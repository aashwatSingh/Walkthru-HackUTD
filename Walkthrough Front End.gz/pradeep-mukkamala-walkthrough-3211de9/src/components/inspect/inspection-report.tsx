"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { ArrowLeft, Copy, GitCompareArrows, Loader2, Pencil, Printer, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { AppHeader } from "@/components/app-header";
import { Badge } from "@/components/ui/badge";
import { Button, buttonVariants } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  conditionMeta,
  findCounterpart,
  formatDateTime,
  inspectionProgress,
  useInspections,
  type Condition,
  type Inspection,
  type Item,
} from "@/lib/inspections";
import { cn } from "@/lib/utils";

const rank: Record<Condition, number> = { good: 0, fair: 1, damaged: 2 };

function ConditionPill({ condition }: { condition: Condition | null }) {
  if (!condition) return <span className="text-xs text-muted-foreground">Not inspected</span>;
  const m = conditionMeta[condition];
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-xs font-medium", m.className)}>
      <span className={cn("size-1.5 rounded-full", m.dot)} />
      {m.label}
    </span>
  );
}

function compareFlag(moveIn?: Item, moveOut?: Item) {
  if (!moveIn?.condition || !moveOut?.condition) return null;
  if (rank[moveOut.condition] > rank[moveIn.condition]) return { label: "Changed since move-in", tone: "text-rose-300" };
  if (moveIn.condition !== "good") return { label: "Pre-existing at move-in", tone: "text-primary" };
  return { label: "No change", tone: "text-muted-foreground" };
}

function matchItem(other: Inspection | undefined, roomName: string, itemName: string) {
  return other?.rooms.find((r) => r.name === roomName)?.items.find((i) => i.name === itemName);
}

function summaryText(i: Inspection) {
  const p = inspectionProgress(i);
  const lines: string[] = [
    `Walkthrough ${i.type} report — ${i.property}, ${i.unit}`,
    ...(i.tenant ? [`Resident: ${i.tenant}`] : []),
    `Inspected: ${formatDateTime(i.createdAt)}`,
    `${p.done}/${p.total} items rated, ${p.photos} photos, ${p.damaged} damaged`,
    "",
    ...i.rooms.flatMap((r) =>
      r.items
        .filter((it) => it.condition && it.condition !== "good")
        .map((it) => `• ${r.name} – ${it.name}: ${conditionMeta[it.condition!].label}${it.note ? ` (${it.note})` : ""}`),
    ),
  ];
  return lines.join("\n");
}

export function InspectionReport() {
  const { id } = useParams<{ id: string }>();
  const inspections = useInspections();
  const inspection = inspections?.find((i) => i.id === id);

  if (inspections === null) {
    return (
      <>
        <AppHeader />
        <div className="flex flex-1 items-center justify-center gap-2 text-muted-foreground">
          <Loader2 className="size-4 animate-spin" /> Preparing report…
        </div>
      </>
    );
  }

  if (!inspection) {
    return (
      <>
        <AppHeader />
        <div className="flex flex-1 flex-col items-center justify-center gap-3 px-4 text-center">
          <h1 className="font-heading text-3xl font-bold">Report not found</h1>
          <p className="text-muted-foreground">This inspection may have been deleted or saved in a different browser.</p>
          <Link href="/inspect" className={buttonVariants()}>
            Go to your walkthroughs
          </Link>
        </div>
      </>
    );
  }

  const counterpart = findCounterpart(inspections, inspection);
  const moveIn = inspection.type === "move-in" ? inspection : counterpart;
  const moveOut = inspection.type === "move-out" ? inspection : counterpart;
  const comparing = Boolean(moveIn && moveOut);
  const p = inspectionProgress(inspection);
  const counts = inspection.rooms
    .flatMap((r) => r.items)
    .reduce(
      (acc, it) => {
        if (it.condition) acc[it.condition]++;
        return acc;
      },
      { good: 0, fair: 0, damaged: 0 } as Record<Condition, number>,
    );

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(summaryText(inspection));
      toast.success("Summary copied. Paste it into an email to your RA or landlord.");
    } catch {
      toast.error("Your browser blocked clipboard access.");
    }
  };

  return (
    <>
      <AppHeader>
        <Link href={`/inspect/${inspection.id}`} className={buttonVariants({ variant: "ghost", size: "sm" })}>
          <Pencil /> Edit
        </Link>
      </AppHeader>
      <main className="mx-auto w-full max-w-5xl flex-1 px-4 py-6 sm:px-6 sm:py-8">
        <div className="no-print flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
          <Link href="/inspect" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="size-3.5" /> All walkthroughs
          </Link>
          <div className="flex gap-2">
            <Button variant="outline" onClick={copy}>
              <Copy /> Copy summary
            </Button>
            <Button onClick={() => window.print()}>
              <Printer /> Save as PDF
            </Button>
          </div>
        </div>

        <Card className="mt-5">
          <CardContent className="space-y-6">
            <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-start">
              <div>
                <div className="flex items-center gap-2 text-sm font-medium text-primary">
                  <ShieldCheck className="size-4" /> Walkthrough condition report
                </div>
                <h1 className="mt-1 font-heading text-3xl font-extrabold tracking-tight sm:text-4xl">
                  {inspection.property} · {inspection.unit}
                </h1>
                <p className="text-sm text-muted-foreground">
                  {inspection.type === "move-in" ? "Move-in" : "Move-out"} inspection
                  {inspection.tenant && ` by ${inspection.tenant}`}
                </p>
              </div>
              <dl className="grid grid-cols-2 gap-x-6 gap-y-1 text-sm sm:text-right">
                <dt className="text-muted-foreground">Started</dt>
                <dd>{formatDateTime(inspection.createdAt)}</dd>
                <dt className="text-muted-foreground">Completed</dt>
                <dd>{inspection.completedAt ? formatDateTime(inspection.completedAt) : "In progress"}</dd>
              </dl>
            </div>

            <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
              {[
                { label: "Items rated", value: `${p.done}/${p.total}` },
                { label: "Good", value: counts.good },
                { label: "Fair", value: counts.fair },
                { label: "Damaged", value: counts.damaged },
                { label: "Photos", value: p.photos },
              ].map((s) => (
                <div key={s.label} className="rounded-2xl bg-muted px-4 py-3">
                  <div className="text-xs text-muted-foreground">{s.label}</div>
                  <div className="font-heading text-3xl font-extrabold">{s.value}</div>
                </div>
              ))}
            </div>

            {comparing ? (
              <div className="flex items-start gap-2 rounded-2xl border border-primary/40 bg-accent p-4 text-sm">
                <GitCompareArrows className="mt-0.5 size-4 shrink-0 text-primary" />
                <p>
                  Compared with the {counterpart!.type} inspection from {formatDateTime(counterpart!.createdAt)}. Items
                  that were already worn or damaged at move-in are labeled <strong>pre-existing</strong>.
                </p>
              </div>
            ) : (
              inspection.type === "move-in" && (
                <p className="no-print rounded-lg border border-dashed p-3 text-sm text-muted-foreground">
                  When you move out, start a move-out walkthrough with the same building and room. This report will
                  then show both inspections side by side.
                </p>
              )
            )}
          </CardContent>
        </Card>

        <div className="mt-6 space-y-6">
          {inspection.rooms.map((room) => (
            <section key={room.id} className="break-inside-avoid">
              <h2 className="mb-3 font-heading text-2xl font-bold">{room.name}</h2>
              <Card size="sm" className="py-0">
                <div className="divide-y">
                  {room.items.map((it) => {
                    const inItem = comparing ? matchItem(moveIn, room.name, it.name) : undefined;
                    const outItem = comparing ? matchItem(moveOut, room.name, it.name) : undefined;
                    const flag = compareFlag(inItem, outItem);
                    const other = inspection.type === "move-in" ? outItem : inItem;
                    return (
                      <div key={it.id} className="grid gap-3 p-3 sm:grid-cols-[1fr_auto] sm:p-4">
                        <div className="min-w-0 space-y-1.5">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-medium">{it.name}</span>
                            {flag && <span className={cn("text-xs font-medium", flag.tone)}>· {flag.label}</span>}
                          </div>
                          {it.note && <p className="text-sm text-muted-foreground">{it.note}</p>}
                          {it.photos.length > 0 && (
                            <div className="flex flex-wrap gap-2 pt-1">
                              {it.photos.map((ph) => (
                                <figure key={ph.id} className="w-24">
                                  {/* eslint-disable-next-line @next/next/no-img-element */}
                                  <img src={ph.dataUrl} alt={`${it.name}`} className="aspect-square w-24 rounded-md border object-cover" />
                                  <figcaption className="mt-0.5 text-[10px] text-muted-foreground">
                                    {formatDateTime(ph.takenAt)}
                                  </figcaption>
                                </figure>
                              ))}
                            </div>
                          )}
                        </div>
                        <div className="flex items-start gap-4 sm:justify-end">
                          {comparing && other && (
                            <div className="space-y-1 text-right">
                              <div className="text-[10px] tracking-wide text-muted-foreground uppercase">
                                {inspection.type === "move-in" ? "Move-out" : "Move-in"}
                              </div>
                              <ConditionPill condition={other.condition} />
                            </div>
                          )}
                          <div className="space-y-1 text-right">
                            {comparing && (
                              <div className="text-[10px] tracking-wide text-muted-foreground uppercase">
                                {inspection.type === "move-in" ? "Move-in" : "Move-out"}
                              </div>
                            )}
                            <ConditionPill condition={it.condition} />
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </Card>
            </section>
          ))}
        </div>

        <p className="mt-8 text-center text-xs text-muted-foreground">
          Generated by Walkthrough on {formatDateTime(new Date().toISOString())}. Photo times reflect when each image
          was added to this inspection.
        </p>
        <div className="mt-2 flex justify-center">
          <Badge variant="outline">Report ID {inspection.id}</Badge>
        </div>
      </main>
    </>
  );
}
