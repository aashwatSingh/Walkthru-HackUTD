"use client";

import { useSyncExternalStore } from "react";

export type Condition = "good" | "fair" | "damaged";
export type InspectionType = "move-in" | "move-out";
export type HousingType = "residence-hall" | "apartment";

export type Photo = { id: string; dataUrl: string; takenAt: string };

export type Item = {
  id: string;
  name: string;
  condition: Condition | null;
  note: string;
  photos: Photo[];
};

export type Room = { id: string; name: string; items: Item[] };

export type Inspection = {
  id: string;
  type: InspectionType;
  housing: HousingType;
  property: string;
  unit: string;
  tenant: string;
  createdAt: string;
  completedAt: string | null;
  rooms: Room[];
};

const STORAGE_KEY = "walkthrough.inspections.v1";

const templates: Record<HousingType, Record<string, string[]>> = {
  "residence-hall": {
    Bedroom: ["Walls & paint", "Floor / carpet", "Ceiling", "Window & blinds", "Door & lock", "Bed frame & mattress", "Desk & chair", "Dresser / wardrobe", "Lights & outlets"],
    Bathroom: ["Sink & faucet", "Toilet", "Shower / tub", "Mirror & cabinet", "Floor & tiles", "Exhaust fan"],
    "Common area": ["Walls & paint", "Floor", "Furniture", "Smoke detector"],
  },
  apartment: {
    "Living room": ["Walls & paint", "Floor / carpet", "Windows & screens", "Light fixtures", "Outlets & switches", "Furniture (if furnished)"],
    Kitchen: ["Countertops", "Cabinets & drawers", "Sink & faucet", "Refrigerator", "Stove & oven", "Microwave", "Dishwasher", "Floor"],
    Bedroom: ["Walls & paint", "Floor / carpet", "Closet & doors", "Windows & blinds", "Lights & outlets"],
    Bathroom: ["Sink & faucet", "Toilet", "Shower / tub", "Mirror & cabinet", "Floor & tiles", "Exhaust fan"],
    "Entry & safety": ["Front door & locks", "Smoke detector", "CO detector", "Thermostat"],
  },
};

export const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);

export function createInspection(input: {
  type: InspectionType;
  housing: HousingType;
  property: string;
  unit: string;
  tenant: string;
}): Inspection {
  return {
    ...input,
    id: uid(),
    createdAt: new Date().toISOString(),
    completedAt: null,
    rooms: Object.entries(templates[input.housing]).map(([name, items]) => ({
      id: uid(),
      name,
      items: items.map((n) => ({ id: uid(), name: n, condition: null, note: "", photos: [] })),
    })),
  };
}

export function inspectionProgress(i: Inspection) {
  const items = i.rooms.flatMap((r) => r.items);
  const done = items.filter((it) => it.condition !== null).length;
  return {
    done,
    total: items.length,
    percent: items.length ? Math.round((done / items.length) * 100) : 0,
    damaged: items.filter((it) => it.condition === "damaged").length,
    photos: items.reduce((n, it) => n + it.photos.length, 0),
  };
}

export function findCounterpart(list: Inspection[], i: Inspection) {
  const norm = (s: string) => s.trim().toLowerCase();
  return list
    .filter(
      (o) =>
        o.id !== i.id &&
        o.type !== i.type &&
        norm(o.property) === norm(i.property) &&
        norm(o.unit) === norm(i.unit),
    )
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0];
}

let cache: Inspection[] | null = null;
const listeners = new Set<() => void>();

function read(): Inspection[] {
  if (cache) return cache;
  try {
    cache = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "[]") as Inspection[];
  } catch {
    cache = [];
  }
  return cache;
}

export class StorageFullError extends Error {}

function write(next: Inspection[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  } catch {
    throw new StorageFullError("Your browser storage is full. Remove some photos or older inspections.");
  }
  cache = next;
  listeners.forEach((l) => l());
}

function subscribe(l: () => void) {
  listeners.add(l);
  return () => listeners.delete(l);
}

export function useInspections(): Inspection[] | null {
  return useSyncExternalStore(subscribe, read, () => null);
}

export const inspectionStore = {
  add(i: Inspection) {
    write([i, ...read()]);
  },
  update(id: string, fn: (i: Inspection) => Inspection) {
    write(read().map((i) => (i.id === id ? fn(i) : i)));
  },
  remove(id: string) {
    write(read().filter((i) => i.id !== id));
  },
};

export async function compressImage(file: File, max = 900): Promise<string> {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error("Could not read that image."));
      el.src = url;
    });
    const scale = Math.min(1, max / Math.max(img.width, img.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(img.width * scale);
    canvas.height = Math.round(img.height * scale);
    canvas.getContext("2d")!.drawImage(img, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/jpeg", 0.7);
  } finally {
    URL.revokeObjectURL(url);
  }
}

export const conditionMeta: Record<Condition, { label: string; className: string; dot: string }> = {
  good: { label: "Good", className: "bg-primary/15 text-primary border-primary/40", dot: "bg-primary" },
  fair: { label: "Fair", className: "bg-amber-400/15 text-amber-300 border-amber-400/40", dot: "bg-amber-400" },
  damaged: { label: "Damaged", className: "bg-rose-500/15 text-rose-300 border-rose-500/40", dot: "bg-rose-500" },
};

export const formatDateTime = (iso: string) =>
  new Date(iso).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
