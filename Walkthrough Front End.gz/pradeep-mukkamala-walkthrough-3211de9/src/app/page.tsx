import Link from "next/link";
import {
  ArrowRight,
  ArrowUpRight,
  Camera,
  Clock,
  FileText,
  GitCompareArrows,
  Lock,
  MapPin,
  Scale,
  ShieldCheck,
  Smartphone,
  Sparkle,
  TriangleAlert,
} from "lucide-react";
import { SiteHeader } from "@/components/site-header";
import { Logo } from "@/components/logo";
import { PopWords, Reveal } from "@/components/reveal";
import { buttonVariants } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { cn } from "@/lib/utils";

const steps = [
  {
    icon: MapPin,
    title: "Start on move-in day",
    body: "Pick your residence hall or apartment and get a room-by-room checklist built for student housing.",
    offset: "md:mt-0",
    tilt: -3,
  },
  {
    icon: Camera,
    title: "Snap every surface",
    body: "Walls, floors, desk, mattress, blinds. Every photo is timestamped and pinned to the item it proves.",
    offset: "md:mt-20",
    tilt: 2,
  },
  {
    icon: FileText,
    title: "Send the report",
    body: "Save a clean PDF for your RA or landlord. Do it again at move-out and compare side by side.",
    offset: "md:mt-40",
    tilt: -2,
  },
];

const marquee = [
  "Timestamped photos",
  "Room-by-room checklists",
  "Move-in vs. move-out",
  "PDF reports",
  "Keep your deposit",
  "Fight unfair fines",
];

const faqs = [
  {
    q: "Is a Walkthrough report legally binding?",
    a: "Walkthrough doesn't replace your lease or your school's room condition form. It gives you organized, timestamped evidence to attach to those forms and to any appeal you file.",
  },
  {
    q: "Does it work for off-campus apartments?",
    a: "Yes. Choose 'Apartment' when you start and the checklist adds a kitchen, living room, appliances and entry doors.",
  },
  {
    q: "What if I find damage on move-in?",
    a: "Mark the item as damaged, add a photo and a note, and send the report to your RA or landlord right away. That record is what protects you at move-out.",
  },
  {
    q: "Where are my photos stored?",
    a: "Right now everything stays in your browser on the device you used. Nothing is uploaded unless you choose to share your report.",
  },
];

function Sticker({ children, className, tilt }: { children: React.ReactNode; className?: string; tilt: number }) {
  return (
    <span
      className={cn(
        "animate-float absolute z-10 rounded-full px-4 py-2 font-heading text-sm font-bold shadow-2xl",
        className,
      )}
      style={{ "--tilt": `${tilt}deg` } as React.CSSProperties}
    >
      {children}
    </span>
  );
}

function HeroMock() {
  const items = [
    { name: "Walls & paint", status: "Good", tone: "bg-primary/15 text-primary" },
    { name: "Desk & chair", status: "Fair", tone: "bg-amber-400/15 text-amber-300" },
    { name: "Window blinds", status: "Damaged", tone: "bg-rose-500/15 text-rose-300" },
    { name: "Mattress", status: "Good", tone: "bg-primary/15 text-primary" },
  ];

  return (
    <div className="relative mx-auto w-full max-w-md lg:mr-0">
      <div className="absolute -inset-10 -z-10 rounded-full bg-primary/25 blur-3xl" />
      <Sticker tilt={-8} className="-top-5 -left-4 bg-primary text-primary-foreground sm:-left-10">
        Free for students
      </Sticker>
      <Sticker tilt={7} className="-right-2 -bottom-5 bg-white text-black sm:-right-8 [animation-delay:1.2s]">
        15-minute setup
      </Sticker>
      <div className="rotate-2 rounded-3xl border border-white/15 bg-card p-5 shadow-[0_30px_80px_-20px_rgba(0,0,0,0.8)] transition-transform duration-500 hover:rotate-0 sm:p-6">
        <div className="flex items-start justify-between gap-3 border-b border-white/10 pb-4">
          <div>
            <div className="font-heading text-xl font-bold">Hall B · Room 214</div>
            <div className="text-sm text-muted-foreground">Move-in · Aug 24, 9:41 AM</div>
          </div>
          <span className="rounded-full bg-white/10 px-3 py-1 text-xs font-semibold">3 / 4 rooms</span>
        </div>
        <div className="mt-4 space-y-2.5">
          {items.map((i) => (
            <div key={i.name} className="flex items-center justify-between rounded-2xl bg-white/5 px-3 py-3">
              <div className="flex items-center gap-3">
                <div className="flex size-10 items-center justify-center rounded-xl bg-white/10">
                  <Camera className="size-4 text-white/70" />
                </div>
                <span className="font-medium">{i.name}</span>
              </div>
              <span className={cn("rounded-full px-3 py-1 text-xs font-bold", i.tone)}>{i.status}</span>
            </div>
          ))}
        </div>
        <div className="mt-4 flex items-start gap-2 rounded-2xl border border-rose-500/30 bg-rose-500/10 p-3 text-sm text-rose-200">
          <TriangleAlert className="mt-0.5 size-4 shrink-0" />
          Left slat bent before move-in. 2 photos attached, sent to RA.
        </div>
      </div>
    </div>
  );
}

export default function Home() {
  return (
    <>
      <SiteHeader />
      <main className="flex-1 overflow-x-clip">
        {/* Hero */}
        <section className="relative">
          <div
            aria-hidden
            className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.08)_1px,transparent_0)] [background-size:28px_28px] [mask-image:radial-gradient(ellipse_at_top,black_30%,transparent_75%)]"
          />
          <div className="mx-auto grid max-w-7xl items-center gap-16 px-5 pt-16 pb-24 sm:px-8 md:pt-24 lg:grid-cols-[1.15fr_1fr]">
            <div>
              <p
                className="animate-pop mb-6 inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-4 py-1.5 text-sm font-semibold text-primary"
                style={{ animationDelay: "0ms" }}
              >
                <ShieldCheck className="size-4" /> Move-in & move-out proof for students
              </p>
              <h1 className="font-heading text-[clamp(3rem,8vw,6.5rem)] leading-[0.92] font-extrabold tracking-tight">
                <PopWords text="Don't pay for damage you didn't do." highlight={["didn't"]} startDelay={120} />
              </h1>
              <p
                className="animate-pop mt-8 max-w-xl text-xl leading-relaxed text-white/70 sm:text-2xl"
                style={{ animationDelay: "850ms" }}
              >
                Walk your room, snap the details, and leave with timestamped proof, not a surprise
                fine.
              </p>
              <div className="animate-pop mt-10 flex flex-col gap-3 sm:flex-row" style={{ animationDelay: "1000ms" }}>
                <Link href="/inspect" className={buttonVariants({ size: "xl" })}>
                  Start your walkthrough <ArrowRight />
                </Link>
                <a href="#how-it-works" className={buttonVariants({ variant: "outline", size: "xl" })}>
                  See how it works
                </a>
              </div>
            </div>
            <div className="animate-pop" style={{ animationDelay: "500ms" }}>
              <HeroMock />
            </div>
          </div>
        </section>

        {/* Marquee */}
        <div className="-mx-4 -rotate-2 border-y-2 border-black bg-primary py-4 text-primary-foreground">
          <div className="animate-marquee flex w-max gap-10 font-heading text-3xl font-extrabold tracking-tight uppercase sm:text-4xl">
            {[...marquee, ...marquee].map((m, i) => (
              <span key={i} className="flex items-center gap-10">
                {m}
                <Sparkle className="size-7 fill-current" />
              </span>
            ))}
          </div>
        </div>

        {/* Stats */}
        <section className="mx-auto max-w-7xl px-5 py-28 sm:px-8">
          <div className="grid gap-12 md:grid-cols-3">
            {[
              { stat: "1 in 4", label: "students say they were charged for damage that was there before they moved in." },
              { stat: "$300+", label: "is a typical move-out deduction for carpet, paint or furniture claims." },
              { stat: "15 min", label: "is all it takes to document a standard double room." },
            ].map((s, i) => (
              <Reveal key={s.stat} delay={i * 120} className={cn(i === 1 && "md:mt-16", i === 2 && "md:mt-6")}>
                <div className="font-heading text-7xl font-extrabold tracking-tight text-primary sm:text-8xl">
                  {s.stat}
                </div>
                <p className="mt-3 max-w-xs text-lg text-white/70">{s.label}</p>
              </Reveal>
            ))}
          </div>
        </section>

        {/* How it works */}
        <section id="how-it-works" className="mx-auto max-w-7xl scroll-mt-24 px-5 pb-28 sm:px-8">
          <Reveal>
            <h2 className="max-w-3xl font-heading text-5xl leading-[0.95] font-extrabold tracking-tight sm:text-7xl">
              Three steps. <span className="text-transparent [-webkit-text-stroke:2px_var(--primary)]">Zero</span> surprise fines.
            </h2>
          </Reveal>
          <div className="mt-16 grid gap-8 md:grid-cols-3">
            {steps.map((s, i) => (
              <Reveal key={s.title} delay={i * 150} tilt={s.tilt} className={s.offset}>
                <div
                  className="group h-full rotate-(--tilt) rounded-3xl border border-white/10 bg-card p-8 transition-all duration-500 hover:-translate-y-2 hover:rotate-0 hover:border-primary/60"
                  style={{ "--tilt": `${s.tilt}deg` } as React.CSSProperties}
                >
                  <div className="flex items-center justify-between">
                    <span className="flex size-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-6">
                      <s.icon className="size-7" />
                    </span>
                    <span className="font-heading text-7xl font-extrabold text-transparent transition-colors [-webkit-text-stroke:1.5px_rgba(255,255,255,0.35)] group-hover:text-primary group-hover:[-webkit-text-stroke-color:var(--primary)]">
                      0{i + 1}
                    </span>
                  </div>
                  <h3 className="mt-8 font-heading text-3xl font-bold">{s.title}</h3>
                  <p className="mt-3 text-lg leading-relaxed text-white/65">{s.body}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </section>

        {/* Features bento */}
        <section id="features" className="scroll-mt-24 border-t border-white/10 bg-white text-black">
          <div className="mx-auto max-w-7xl px-5 py-28 sm:px-8">
            <Reveal>
              <h2 className="max-w-4xl font-heading text-5xl leading-[0.95] font-extrabold tracking-tight sm:text-7xl">
                Evidence that{" "}
                <span className="inline-block rotate-1 rounded-2xl bg-black px-3 text-primary">holds up.</span>
              </h2>
            </Reveal>
            <div className="mt-16 grid auto-rows-[minmax(220px,auto)] gap-5 md:grid-cols-6">
              <Reveal className="md:col-span-4 md:row-span-2">
                <div className="group flex h-full flex-col justify-between rounded-3xl bg-black p-8 text-white sm:p-10">
                  <GitCompareArrows className="size-12 text-primary transition-transform duration-500 group-hover:rotate-180" />
                  <div>
                    <h3 className="font-heading text-4xl font-extrabold sm:text-5xl">Move-in vs. move-out, side by side.</h3>
                    <p className="mt-4 max-w-lg text-lg text-white/70">
                      Every item gets a label: changed since move-in, or pre-existing. That one line is usually all it
                      takes to get a charge dropped.
                    </p>
                  </div>
                </div>
              </Reveal>
              <Reveal delay={100} className="md:col-span-2">
                <div className="flex h-full flex-col justify-between rounded-3xl bg-primary p-7">
                  <Clock className="size-9" />
                  <div>
                    <h3 className="font-heading text-2xl font-bold">Timestamped photos</h3>
                    <p className="mt-2 text-black/70">Each photo records exactly when you added it.</p>
                  </div>
                </div>
              </Reveal>
              <Reveal delay={200} className="md:col-span-2">
                <div className="flex h-full flex-col justify-between rounded-3xl border-2 border-black p-7">
                  <Smartphone className="size-9" />
                  <div>
                    <h3 className="font-heading text-2xl font-bold">Made for your phone</h3>
                    <p className="mt-2 text-black/70">Your camera opens right inside each checklist item.</p>
                  </div>
                </div>
              </Reveal>
              <Reveal delay={100} className="md:col-span-3">
                <div className="flex h-full flex-col justify-between rounded-3xl border-2 border-black p-7">
                  <Scale className="size-9" />
                  <div>
                    <h3 className="font-heading text-2xl font-bold">Dispute-ready in minutes</h3>
                    <p className="mt-2 text-black/70">
                      Copy a summary of every damaged item and paste it straight into your appeal email.
                    </p>
                  </div>
                </div>
              </Reveal>
              <Reveal delay={200} className="md:col-span-3">
                <div className="flex h-full flex-col justify-between rounded-3xl bg-black p-7 text-white">
                  <div className="flex gap-3">
                    <FileText className="size-9 text-primary" />
                    <Lock className="size-9 text-white/60" />
                  </div>
                  <div>
                    <h3 className="font-heading text-2xl font-bold">Clean PDFs, private by default</h3>
                    <p className="mt-2 text-white/70">
                      Reports mirror the room condition forms schools already use, and stay on your device until you
                      share them.
                    </p>
                  </div>
                </div>
              </Reveal>
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="mx-auto max-w-7xl px-5 py-28 sm:px-8">
          <Reveal>
            <h2 className="font-heading text-5xl font-extrabold tracking-tight sm:text-6xl">Students got their money back.</h2>
          </Reveal>
          <div className="mt-14 grid gap-8 md:grid-cols-3">
            {[
              {
                quote: "My hall tried to charge me $180 for a stained mattress. I sent my move-in photo and the charge was gone the next day.",
                name: "Priya S.",
                school: "Sophomore, State University",
                tilt: -2,
                style: "bg-card border border-white/10",
              },
              {
                quote: "Our landlord kept half our deposit for 'wall damage.' The side-by-side comparison got all of it back.",
                name: "Marcus T.",
                school: "Senior, off-campus apartment",
                tilt: 2,
                style: "bg-primary text-primary-foreground md:mt-12",
              },
              {
                quote: "As an RA I tell every resident to use it. Disputes take minutes now instead of weeks.",
                name: "Jordan L.",
                school: "Resident Assistant",
                tilt: -1,
                style: "bg-white text-black md:mt-4",
              },
            ].map((t, i) => (
              <Reveal key={t.name} delay={i * 130} tilt={t.tilt}>
                <figure
                  className={cn(
                    "flex h-full rotate-(--tilt) flex-col justify-between gap-8 rounded-3xl p-8 transition-all duration-500 hover:scale-[1.03] hover:rotate-0",
                    t.style,
                  )}
                  style={{ "--tilt": `${t.tilt}deg` } as React.CSSProperties}
                >
                  <blockquote className="font-heading text-2xl leading-snug font-semibold">&ldquo;{t.quote}&rdquo;</blockquote>
                  <figcaption>
                    <div className="font-bold">{t.name}</div>
                    <div className="opacity-70">{t.school}</div>
                  </figcaption>
                </figure>
              </Reveal>
            ))}
          </div>
        </section>

        {/* Pricing */}
        <section id="pricing" className="scroll-mt-24 border-t border-white/10">
          <div className="mx-auto max-w-7xl px-5 py-28 sm:px-8">
            <Reveal className="text-center">
              <h2 className="font-heading text-5xl font-extrabold tracking-tight sm:text-7xl">
                Free. <span className="text-primary">Seriously.</span>
              </h2>
              <p className="mx-auto mt-5 max-w-xl text-xl text-white/70">
                Walkthrough is free for every student. Housing offices can bring it to their whole campus.
              </p>
            </Reveal>
            <div className="mx-auto mt-16 grid max-w-5xl items-start gap-8 md:grid-cols-2">
              <Reveal tilt={-2}>
                <div className="rounded-3xl border-2 border-primary bg-card p-8 sm:p-10">
                  <div className="font-heading text-2xl font-bold">Student</div>
                  <div className="mt-4 font-heading text-7xl font-extrabold">
                    $0<span className="text-xl font-medium text-white/60"> forever</span>
                  </div>
                  <ul className="mt-8 space-y-3 text-lg">
                    {["Unlimited walkthroughs", "Timestamped photos & notes", "PDF reports", "Move-in vs. move-out compare"].map((f) => (
                      <li key={f} className="flex items-center gap-3">
                        <span className="size-2.5 rotate-45 bg-primary" /> {f}
                      </li>
                    ))}
                  </ul>
                  <Link href="/inspect" className={cn(buttonVariants({ size: "xl" }), "mt-10 w-full")}>
                    Start your walkthrough
                  </Link>
                </div>
              </Reveal>
              <Reveal delay={150} tilt={2} className="md:mt-12">
                <div className="rounded-3xl bg-white p-8 text-black sm:p-10">
                  <div className="flex items-center justify-between">
                    <div className="font-heading text-2xl font-bold">Campus</div>
                    <span className="rounded-full bg-black px-3 py-1 text-xs font-bold text-primary">Coming soon</span>
                  </div>
                  <div className="mt-4 font-heading text-7xl font-extrabold">Custom</div>
                  <ul className="mt-8 space-y-3 text-lg">
                    {["Checklists for each building", "Staff dashboard & exports", "Appeals workflow", "University sign-in"].map((f) => (
                      <li key={f} className="flex items-center gap-3">
                        <span className="size-2.5 rotate-45 bg-black" /> {f}
                      </li>
                    ))}
                  </ul>
                  <a
                    href="mailto:campus@walkthrough.app"
                    className={cn(
                      buttonVariants({ size: "xl" }),
                      "mt-10 w-full bg-black text-white active:bg-white active:text-black active:ring-2 active:ring-black",
                    )}
                  >
                    Join the waitlist <ArrowUpRight />
                  </a>
                </div>
              </Reveal>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section id="faq" className="mx-auto max-w-4xl scroll-mt-24 px-5 pb-28 sm:px-8">
          <Reveal>
            <h2 className="font-heading text-5xl font-extrabold tracking-tight sm:text-6xl">Questions?</h2>
          </Reveal>
          <Reveal delay={100}>
            <Accordion className="mt-10">
              {faqs.map((f) => (
                <AccordionItem key={f.q} value={f.q} className="border-white/15">
                  <AccordionTrigger className="py-6 font-heading text-xl font-bold hover:text-primary hover:no-underline sm:text-2xl">
                    {f.q}
                  </AccordionTrigger>
                  <AccordionContent className="text-lg text-white/70">{f.a}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </Reveal>
        </section>

        {/* CTA */}
        <section className="mx-auto max-w-7xl px-5 pb-28 sm:px-8">
          <Reveal tilt={-1.5}>
            <div className="relative overflow-hidden rounded-[2.5rem] border-2 border-primary bg-card px-8 py-16 text-center sm:px-16 sm:py-24">
              <div aria-hidden className="absolute -top-24 -right-24 size-72 rounded-full bg-primary/30 blur-3xl" />
              <div aria-hidden className="absolute -bottom-24 -left-24 size-72 rounded-full bg-primary/20 blur-3xl" />
              <h2 className="relative font-heading text-5xl leading-[0.95] font-extrabold tracking-tight sm:text-7xl">
                Moving in soon?
                <br />
                <span className="text-primary">Document it today.</span>
              </h2>
              <p className="relative mx-auto mt-6 max-w-lg text-xl text-white/70">
                The best time to stop a fine is before you unpack your first box.
              </p>
              <Link href="/inspect" className={cn(buttonVariants({ size: "xl" }), "relative mt-10")}>
                <ShieldCheck /> Start your walkthrough
              </Link>
            </div>
          </Reveal>
        </section>
      </main>

      <footer className="overflow-hidden border-t border-white/10">
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-4 px-5 pt-10 text-white/60 sm:flex-row sm:items-center sm:px-8">
          <Logo className="text-white" />
          <p>© 2026 Walkthrough. Helping students move out with their deposits.</p>
        </div>
        <div
          aria-hidden
          className="mx-auto -mb-[0.2em] max-w-7xl px-5 pt-6 font-heading text-[clamp(4rem,17vw,15rem)] leading-none font-extrabold tracking-tighter text-transparent select-none [-webkit-text-stroke:2px_rgba(255,255,255,0.14)] sm:px-8"
        >
          Walkthrough
        </div>
      </footer>
    </>
  );
}
