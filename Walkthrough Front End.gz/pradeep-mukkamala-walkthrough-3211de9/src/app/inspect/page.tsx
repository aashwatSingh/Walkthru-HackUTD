"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ClipboardList, FileText, Loader2, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { AppHeader } from "@/components/app-header";
import { ChoiceGroup } from "@/components/choice-group";
import { Badge } from "@/components/ui/badge";
import { Button, buttonVariants } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import {
  createInspection,
  formatDateTime,
  inspectionProgress,
  inspectionStore,
  useInspections,
  type HousingType,
  type InspectionType,
} from "@/lib/inspections";
import { cn } from "@/lib/utils";

function NewInspectionDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const router = useRouter();
  const [type, setType] = useState<InspectionType>("move-in");
  const [housing, setHousing] = useState<HousingType>("residence-hall");
  const [property, setProperty] = useState("");
  const [unit, setUnit] = useState("");
  const [tenant, setTenant] = useState("");
  const [touched, setTouched] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setTouched(true);
    if (!property.trim() || !unit.trim()) return;
    const inspection = createInspection({ type, housing, property: property.trim(), unit: unit.trim(), tenant: tenant.trim() });
    inspectionStore.add(inspection);
    onOpenChange(false);
    router.push(`/inspect/${inspection.id}`);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <form onSubmit={submit} className="space-y-5">
          <DialogHeader>
            <DialogTitle className="font-heading text-2xl font-extrabold">New walkthrough</DialogTitle>
            <DialogDescription>
              Tell us where you live and we&apos;ll build your room-by-room checklist.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-2">
            <Label>Inspection type</Label>
            <ChoiceGroup
              label="Inspection type"
              value={type}
              onChange={setType}
              options={[
                { value: "move-in", label: "Move-in", hint: "Record the starting condition" },
                { value: "move-out", label: "Move-out", hint: "Show how you left it" },
              ]}
            />
          </div>
          <div className="space-y-2">
            <Label>Housing</Label>
            <ChoiceGroup
              label="Housing type"
              value={housing}
              onChange={setHousing}
              options={[
                { value: "residence-hall", label: "Residence hall", hint: "Dorm room & shared bath" },
                { value: "apartment", label: "Apartment", hint: "Kitchen, living room & more" },
              ]}
            />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="property">Building or address</Label>
              <Input
                id="property"
                placeholder="e.g. Hall B, North Campus"
                value={property}
                onChange={(e) => setProperty(e.target.value)}
                aria-invalid={touched && !property.trim()}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="unit">Room / unit</Label>
              <Input
                id="unit"
                placeholder="e.g. 214"
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                aria-invalid={touched && !unit.trim()}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="tenant">Your name</Label>
              <Input id="tenant" placeholder="Optional" value={tenant} onChange={(e) => setTenant(e.target.value)} />
            </div>
          </div>
          {touched && (!property.trim() || !unit.trim()) && (
            <p className="text-sm text-destructive">Add the building and room so your report is easy to match later.</p>
          )}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">Start inspection</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function InspectionsPage() {
  const inspections = useInspections();
  const [open, setOpen] = useState(false);

  return (
    <>
      <AppHeader />
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-10 sm:px-6">
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <h1 className="font-heading text-4xl font-extrabold tracking-tight sm:text-6xl">
              Your <span className="text-primary">walkthroughs</span>
            </h1>
            <p className="mt-3 text-lg text-muted-foreground">
              Inspections are saved in this browser. Finish one to generate a shareable report.
            </p>
          </div>
          <Button size="lg" onClick={() => setOpen(true)}>
            <Plus /> New walkthrough
          </Button>
        </div>

        {inspections === null ? (
          <div className="flex items-center gap-2 py-24 text-muted-foreground">
            <Loader2 className="size-4 animate-spin" /> Loading your inspections…
          </div>
        ) : inspections.length === 0 ? (
          <Card className="mt-10 rounded-3xl border-2 border-dashed border-white/15 ring-0">
            <CardContent className="flex flex-col items-center py-14 text-center">
              <span className="flex size-16 -rotate-6 items-center justify-center rounded-2xl bg-primary text-primary-foreground">
                <ClipboardList className="size-8" />
              </span>
              <h2 className="mt-6 font-heading text-3xl font-bold">No walkthroughs yet</h2>
              <p className="mt-2 max-w-md text-base text-muted-foreground">
                Start your move-in inspection before you unpack. You&apos;ll get a checklist for every
                room and a report you can send to your RA or landlord.
              </p>
              <Button size="lg" className="mt-8" onClick={() => setOpen(true)}>
                <Plus /> Start your first walkthrough
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {inspections.map((i) => {
              const p = inspectionProgress(i);
              return (
                <Card key={i.id} className="rounded-3xl transition-all duration-300 hover:-translate-y-1 hover:ring-primary/60">
                  <CardContent className="space-y-4">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <Link href={`/inspect/${i.id}`} className="block truncate font-heading text-xl font-bold transition-colors hover:text-primary">
                          {i.property} · {i.unit}
                        </Link>
                        <p className="text-xs text-muted-foreground">Started {formatDateTime(i.createdAt)}</p>
                      </div>
                      <Badge variant={i.type === "move-in" ? "secondary" : "outline"}>
                        {i.type === "move-in" ? "Move-in" : "Move-out"}
                      </Badge>
                    </div>
                    <div className="space-y-1.5">
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>
                          {p.done}/{p.total} items · {p.photos} photos
                        </span>
                        <span>{i.completedAt ? "Completed" : `${p.percent}%`}</span>
                      </div>
                      <Progress value={p.percent} />
                    </div>
                    {p.damaged > 0 && (
                      <p className="text-xs font-medium text-rose-300">
                        {p.damaged} item{p.damaged > 1 ? "s" : ""} marked damaged
                      </p>
                    )}
                    <div className="flex gap-2">
                      <Link href={`/inspect/${i.id}`} className={cn(buttonVariants({ size: "sm" }), "flex-1")}>
                        {i.completedAt ? "Review" : "Continue"}
                      </Link>
                      <Link
                        href={`/inspect/${i.id}/report`}
                        className={buttonVariants({ variant: "outline", size: "sm" })}
                      >
                        <FileText /> Report
                      </Link>
                      <Button
                        variant="ghost"
                        size="icon-sm"
                        aria-label="Delete inspection"
                        onClick={() => {
                          if (confirm("Delete this inspection and its photos? This can't be undone.")) {
                            inspectionStore.remove(i.id);
                            toast("Inspection deleted");
                          }
                        }}
                      >
                        <Trash2 />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </main>
      <NewInspectionDialog open={open} onOpenChange={setOpen} />
    </>
  );
}
