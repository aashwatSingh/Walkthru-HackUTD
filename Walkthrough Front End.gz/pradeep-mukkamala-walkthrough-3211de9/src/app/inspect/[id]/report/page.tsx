import { Suspense } from "react";
import { InspectionReport } from "@/components/inspect/inspection-report";
import { PageLoading } from "@/components/inspect/page-loading";

export default function Page() {
  return (
    <Suspense fallback={<PageLoading label="Preparing report…" />}>
      <InspectionReport />
    </Suspense>
  );
}
