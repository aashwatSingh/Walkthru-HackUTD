import { Suspense } from "react";
import { InspectionEditor } from "@/components/inspect/inspection-editor";
import { PageLoading } from "@/components/inspect/page-loading";

export default function Page() {
  return (
    <Suspense fallback={<PageLoading label="Loading inspection…" />}>
      <InspectionEditor />
    </Suspense>
  );
}
