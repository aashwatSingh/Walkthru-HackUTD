# Walkthrough

Walkthrough is a website template for a web app that protects university students from unfair housing fines. Students document their room on move-in and move-out day with condition ratings, notes and timestamped photos. They then share an itemized report with their RA or landlord.

## What's included

- **Landing page** (`/`): hero, how it works, features, testimonials, pricing (student and campus plans), FAQ and calls to action.
- **Walkthroughs** (`/inspect`): start a move-in or move-out inspection for a residence hall or apartment. Each housing type gets its own room-by-room checklist.
- **Inspection editor** (`/inspect/[id]`): rate each item as Good, Fair or Damaged, add notes, attach photos (the camera opens on mobile) and add custom items.
- **Report** (`/inspect/[id]/report`): an itemized, printable report (Save as PDF) with photo timestamps and a copyable summary. If a move-in and a move-out inspection share the same building and room, the report compares them and marks each item as *changed since move-in* or *pre-existing*.

Data lives in the browser's `localStorage`, so there is no account or backend yet. Photos are downscaled before they are saved.

## Stack

Next.js 16 (App Router), TypeScript, Tailwind CSS v4, shadcn/ui (Base UI) and lucide-react icons.

## Running locally

```bash
npm install
npm run dev      # http://localhost:4317
```

Other scripts:

```bash
npm run build && npm start   # production build on port 4317
npm run lint
```

## Project layout

```
src/app/page.tsx                    Marketing landing page
src/app/inspect/page.tsx            Inspection list + new walkthrough dialog
src/app/inspect/[id]/               Editor and report routes
src/components/inspect/             Client views for editor and report
src/lib/inspections.ts              Data model, room templates, localStorage store
```

To change the checklists, edit `templates` in `src/lib/inspections.ts`.
